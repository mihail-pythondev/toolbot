from KoTuK.sqlite3Test.sqliteTest import getStatus
from database import *
# from Tools.search import *
import faker
import random
from requests.exceptions import RequestException
from faker import Faker
import requests
import json
import os
import telebot
from telebot import types

# Путь к файлу конфигурации
CONFIG_FILE = 'config.json'


# Функция загрузки конфигурации
def load_config():
    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError("Конфигурационный файл не найден!")

    with open(CONFIG_FILE, 'r', encoding='utf-8') as file:
        return json.load(file)


# Функция сохранения конфигурации
def save_config(config):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as file:
        json.dump(config, file, ensure_ascii=False, indent=4)


# Пример использования
def get_token():
    config = load_config()
    return config.get('TOKEN')


def get_admins():
    config = load_config()
    return config.get('ADMINS', [])


def get_channels():
    config = load_config()
    return config.get('CHANNELS', {})


def get_manuals():
    config = load_config()
    return config.get('MANUALS', [])


def get_ai_list():
    config = load_config()
    return config.get('AI_LIST', [])


def get_chat_id():
    config = load_config()
    return config.get('CHAT_ID')


# Пример изменения конфигурации
def add_admin(admin_id):
    config = load_config()
    if admin_id not in config['ADMINS']:
        config['ADMINS'].append(admin_id)
        save_config(config)
        return True
    return False


def add_channel(name, channel_link):
    config = load_config()
    if name not in config['CHANNELS']:
        config['CHANNELS'][name] = channel_link
        save_config(config)
        return True
    return False


def add_manual(name, description, content):
    config = load_config()
    config['MANUALS'].append({
        'name': name,
        'description': description,
        'content': content
    })
    save_config(config)

# Функция удаления администратора
def remove_admin(admin_id):
    config = load_config()
    if admin_id in config['ADMINS']:
        config['ADMINS'].remove(admin_id)
        save_config(config)
        return True
    return False

# Функция удаления мануала по имени
def remove_manual(manual_name):
    config = load_config()
    updated_manuals = []
    for manual in config['MANUALS']:
        if manual['name'] != manual_name:
            updated_manuals.append(manual)
    config['MANUALS'] = updated_manuals
    save_config(config)
    return True

def remove_channel(channel_name):
    config = load_config()
    if channel_name in config['CHANNELS']:
        del config['CHANNELS'][channel_name]
        save_config(config)
        return True
    return False

def add_ai(ai_username):
    config = load_config()
    if ai_username not in config['AI_LIST']:
        config['AI_LIST'].append(ai_username)
        save_config(config)
        return True
    return False

# Функция удаления AI бота
def remove_ai(ai_username):
    config = load_config()
    if ai_username in config['AI_LIST']:
        config['AI_LIST'].remove(ai_username)
        save_config(config)
        return True
    return False

def add_proxy(name, text):
    config = load_config()
    config['PROXY'][name] = text
    save_config(config)
    return True
def del_proxy(name):
    config = load_config()
    if name in config['PROXY'].keys():
        del config['PROXY'][name]
        save_config(config)
        return True
    return False
def get_proxy(name):
    config = load_config()
    if name in config['PROXY'].keys():
        save_config(config)
        return config['PROXY'][name]
    return False
def get_all_proxy():
    config = load_config()
    return config['PROXY']

def set_chat_id(new_chat_id):
    config = load_config()
    config['CHAT_ID'] = new_chat_id
    save_config(config)
    return True

bot = telebot.TeleBot(get_token())

fake = Faker(['ru_RU'])
admin_commands = {
    "/set_vip {id}":"Установить вип статус",
    "/del_vip {id}":"Удалить вип статус",
    "/add_admin {id}":"Добавить админа",
    "/del_admin {id}":"Удалить админа",
    "/add_channel {username}":"Добавить спонсора",
    "/del_channel {username}":"Удалить спонсора",
    "/add_ai {username}":"Добавить ссылку на бота с ИИ",
    "/del_ai {username}":"Удалить ссылку на бота с ИИ",
    "/set_chat_id {integer_id}":"Установить айди для чата с созданием ботов",
    "/create_manual {Title}":"Создать мануал",
    "/delete_manual":"Удалить мануал",
    "/subscribers":"Количество пользователей в боте",
    "/set_scammer {id}":"Установить статус скамера",
    "/set_none {id}":"Установить статус Undefined",
    "/set_verif {id}":"Установить статус проверенного",
    "/add_user {id} {username}":"Добавить пользователя в бд скамеров (со статусом Undefined)",
    "/say {id} {text}":"Отправить кому-то сообщение",
    "/bc {text}":"Отправить пост всем пользователям",
    "/add_proxy {Title} {text}":"Добавить Proxy",
    "/del_proxy {Title}":"Удалить Proxy по названию"
}

# НЕ ОЧЕНЬ НУЖНОЕ
# "Сохранить 📂", "Настройки ⚙️", "FaQ 📖", "Новости 📌", "Заявка 📧", "Техподдержка 🛠️",
# СРЕДНЕЕ:
#
# НУЖНОЕ:
# Реф. система - 3 друга = +2 дня випа; Продажа прокси, при випе - некоторые бесплатно


# import datetime
#
# today_date = datetime.date.today()
# date = 20250709
# print(int(str(today_date).replace("-")) > date)

usersDB = Database("users")
peoplesDB = Database("peoples")


def check_subscription(chat_id):
    if not get_channels():
        raise ValueError("Список каналов пуст")

    try:
        for channel_name, channel_link in get_channels().items():
            # Преобразуем ссылку в правильный формат
            if channel_link.startswith('https://t.me/'):
                channel_id = channel_link.replace('https://t.me/', '')
            elif channel_link.startswith('@'):
                channel_id = channel_link
            else:
                raise ValueError(f"Неверный формат ссылки на канал: {channel_link}")

            # Проверяем, что канал существует
            try:
                bot.get_chat(channel_id)  # Пытаемся получить информацию о чате
            except Exception as e:
                print(f"Канал {channel_id} не найден: {e}")
                return False

            member = bot.get_chat_member(channel_id, chat_id)
            if member.status not in ['member', 'creator', 'administrator']:
                return False
        return True
    except Exception as e:
        print(f"Ошибка в check_subscription: {e}")
        return False

def get_time():
    date = datetime.now()
    date_str = date.strftime("%Y-%m-%d %H:%M:%S")
    return date_str


@bot.message_handler(commands=['start'])
def start_message(message):
    try:
        args = message.text.split()
        user_id = message.from_user.id
        username = message.from_user.username

        # Проверка подписки (предполагаем, что метод существует)
        if check_subscription(user_id):
            bot.send_message(user_id, "Привет! Это бот ToolBot от разработчика @kotuk0iq! Данный бот включает в себя разные инструменты, как платные, так и бесплатные!")

            if len(args) > 1:
                referred_by = int(args[1])
                try:
                    if usersDB.check_user_exists(referred_by):
                        if not usersDB.check_user_exists(user_id):
                            usersDB.add_user_with_referral(user_id, referred_by, bot=bot)
                            bot.send_message(user_id, "Спасибо за регистрацию по реферальной ссылке!")
                            print(f"{get_time()} | [{user_id}] @{username} Был зарегистрирован в боте благодаря {args[1]}")
                            # people_status = peoplesDB.getStatus_people(username)
                            # if not people_status:
                            #     peoplesDB.addUser(user_id, username=username)
                        else:
                            bot.send_message(user_id, "Вы уже зарегистрированы в боте")
                    else:
                        bot.send_message(user_id, "Неверный реферальный ID")
                except ValueError:
                    bot.send_message(user_id, "Ошибка в реферальной ссылке")
                if user_id in get_admins():
                    bot.send_message(user_id, "Админ-Панель активирована!")
            else:
                # Проверка статуса пользователя
                status_tuple = usersDB.getStatus(user_id)
                if status_tuple:
                    status = status_tuple[0]
                    if status in ["user", "vip", "admin"]:
                        bot.send_message(user_id, "Успешная авторизация")
                        print(f"{get_time()} | [{user_id}] @{username} Был авторизован в боте")
                else:
                    # Регистрация нового пользователя
                    bot.send_message(user_id, "Регистрация...")


                    # Добавление в основную базу
                    if user_id in get_admins():
                        usersDB.addUser(user_id, username, "admin")
                    else:
                        usersDB.addUser(user_id, username, "default")

                    print(f"{get_time()} | [{user_id}] @{username} Был зарегистрирован в боте")

            if not peoplesDB.user_exists_in_peoples(user_id):
                peoplesDB.addUser(user_id, username=username)
                print(f"{get_time()} | [{user_id}] Добавлен @{username} в БД скамеров")
            else: print(f"{get_time()} | [{user_id}] @{username} уже существует в БД скамеров")
            # Создание клавиатуры
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item1 = types.KeyboardButton("Поиск по базе🔍")
            item2 = types.KeyboardButton("Нейросеть 🤖")
            item3 = types.KeyboardButton("Советы 🎁")

            markup.row(item1, types.KeyboardButton("Купить VIP 📥"))
            markup.row(item2, item3)
            markup.row(
                types.KeyboardButton("🔑 Генерация пароля"),
                types.KeyboardButton("💻 GET-Запрос"),
                types.KeyboardButton("💰 Курс валют")
            )
            markup.row(
                types.KeyboardButton("👨 Фейк-Личность"),
                types.KeyboardButton("🤖 Создать Бота")
            )
            markup.row(types.KeyboardButton("🔗 Реферальная система"), types.KeyboardButton("🔐 PROXY"))

            if user_id in get_admins():
                markup.row(types.KeyboardButton("АДМИН-ПАНЕЛЬ"))

            bot.send_message(user_id, "Выберите действие: ", reply_markup=markup)

        else:
            keyboard = types.InlineKeyboardMarkup()
            for channel_name, channel_link in get_channels().items():
                if channel_link.startswith('@'):
                    url = f"https://t.me/{channel_link[1:]}"  # убираем @ и формируем URL
                elif channel_link.startswith('https://t.me/'):
                    url = channel_link
                else:
                    url = f"https://t.me/{channel_link}"  # если передан просто название канала
                keyboard.add(types.InlineKeyboardButton(text=channel_name, url=url))

            bot.reply_to(message, "Для доступа к функционалу бота, пожалуйста, подпишитесь на все каналы:",
                         reply_markup=keyboard)

    except Exception as e:
        bot.send_message(user_id, "Произошла ошибка при обработке команды")
        print(f"{get_time()} | Ошибка в start_message: {e}")


list_cmds = []
man_info = []
for i in admin_commands.keys():
    i = i.replace(" {id}", "").replace(" {username}", "").replace(" {text}","").replace(" {Title}", "").replace(" {integer_id}", "")
    list_cmds.append(i.replace("/",""))
@bot.message_handler(commands=list_cmds)
def admin_cmds(message):
    try:
        id = message.from_user.id
        print(f"{get_time()} | {id} ввел админ-команду")
        text = message.text.split()
        if id in get_admins():
            print(f"{get_time()} | {id} is Admin")
            username = f"@{message.from_user.username}"
            usern = message.from_user.username
            command = message.text.split()[0][1:]
            if command == "set_vip":
                end_date = datetime.now() + timedelta(days=30)
                estr = end_date.strftime("%Y-%m-%d %H:%M:%S")
                usersDB.setData(int(text[1]), status="vip", vip_end_date=estr)
                bot.reply_to(message, f"Выдан вип пользователю {text[1]}")
                bot.send_message(int(text[1]), f"Вам выдан VIP 🎉\nДействует до {estr}")
            elif command == "del_vip":
                usersDB.setData(int(text[1]), status="user", vip_end_date=0)
                bot.reply_to(message, f"Удален вип у пользователя {int(text[1])}")
                bot.send_message(int(text[1]), "У вас забрали VIP :(")
            elif command == "add_admin":
                add_admin(int(text[1]))
                bot.send_message(int(text[1]), "Вы - новый админ 🎉")
                bot.reply_to(message, f"Добавлен новый админ {text[1]}")
            elif command == "del_admin":
                remove_admin(int(text[1]))
                bot.send_message(int(text[1]), "Вы были сняты с должности админа")
                bot.reply_to(message, f"Удален админ {text[1]}")
            elif command == "add_channel":
                add_channel(text[1], text[2])
                bot.reply_to(message, f"Добавлен спонсор {text[1]} с ссылкой {text[2]}")
            elif command == "del_channel":
                remove_channel(text[1])
                bot.reply_to(message, f"Удален канал с именем {text[1]}")
            elif command == "add_ai":
                add_ai(text[1])
                bot.reply_to(message, f"Добавлен ИИ {text[1]}")
            elif command == "del_ai":
                remove_ai(text[1])
                bot.reply_to(message, f"Удален ИИ {text[1]}")
            elif command == "set_chat_id":
                set_chat_id(int(text[1]))
                bot.reply_to(message, f"Заменен айди чата на {text[1]}")
            elif command == "create_manual":
                man_info = [text[1:]]
                bot.send_message(message, "Отправьте описание мануала")
                bot.register_next_step_handler(message, set_description)
            elif command == "delete_manual":
                remove_manual(text[1])
                bot.reply_to(message, f"Мануал {text[1]} удален")
            elif command == "subscribers":
                subscriber_count = usersDB.get_user_count()
                bot.reply_to(message, f"Подписчики: {subscriber_count}")
                print(f"{get_time()} | Подписчики: {subscriber_count}")
            elif command == "set_scammer":
                peoplesDB.setData(id=int(text[1]),status="Scammer")
                bot.reply_to(message, f"Статус для {text[1]} установлен на Scammer")
            elif command == "set_none":
                peoplesDB.setData(int(text[1]), status="Undefinied")
                bot.reply_to(message, f"Статус для {text[1]} установлен на Undefinied")
            elif command == "set_verif":
                peoplesDB.setData(int(text[1]), status="Verificated")
                bot.reply_to(message, f"Статус для {text[1]} установлен на Verificated")
            elif command == "add_user":
                peoplesDB.addUser(id=int(text[1]), username=text[2], status="Undefinied")
            elif command == "say":
                message_text = text[2:]
                rTEXT = ""
                for i in message_text:
                    rTEXT += i+" "
                rTEXT = rTEXT.replace("\\n", "\n")
                bot.send_message(int(text[1]), f"Сообщение от админа вам: \n\n{rTEXT}")
                bot.reply_to(message, f"Отправлено:\n\n{rTEXT}")
            elif command == "bc":
                rTEXT = ""
                for i in text[1:]:
                    rTEXT += i + " "
                rTEXT = rTEXT.replace("\\n", "\n")
                usersDB.broadcast_message(bot, rTEXT)
            elif command == "add_proxy":
                rTEXT = ""
                for i in text[2:]:
                    rTEXT += i + " "
                rTEXT = rTEXT.replace("\\n", "\n")
                add_proxy(text[1], rTEXT)
                bot.send_message(id, f"Создан новый Proxy {text[1]} с описанием \n{rTEXT}")
            elif command == "del_proxy":
                if del_proxy(text[1]): bot.reply_to(message, "Конфиг удален")
                else: bot.send_message(id, "Error")
            elif command == "del_user":
                peoplesDB.delete_user_from_peoples(id)
            else:
                bot.reply_to(message, "Неизвестная команда")
        else:
            bot.reply_to(message, "У вас нет доступа к админке.")
    except Exception as e:
        print(f"{get_time()} | Ошибка в admin_cmds: \"{e}\"")

def set_description(message):
    id = message.from_user.id
    man_info.append(message.text)
    bot.send_message(id, "Введите текст мануала")
    bot.register_next_step_handler(message, manual)
def manual(message):
    id = message.from_user.id
    man_info.append(message.text)
    add_manual(man_info[0], man_info[1], man_info[2])
    bot.send_message(id, f"Создан новый мануал:\n\n{man_info[0]}:\n* {man_info[1]}\n\n{man_info[2]}")

@bot.message_handler(func=lambda m: not m.text.startswith('/'))
def commands(message):
    try:
        id = message.from_user.id
        username = f"@{message.from_user.username}"
        if message.text == "Поиск по базе🔍":
            bot.send_message(id, f"{username}, введите пожалуйста @username человека которого будем искать")
            bot.register_next_step_handler(message, process_searching)
        elif message.text == "АДМИН-ПАНЕЛЬ":
            cmds = ""
            for i in admin_commands.keys():
                cmds += f"\n{i} - {admin_commands[i]}"
            bot.send_message(id, f"Добро пожаловать {username}\n```\nADMIN-COMMANDS:\n\n{cmds}\n```", parse_mode="Markdown")
        elif message.text == "Советы 🎁":
            localStatus = usersDB.getStatus(id)
            if id in get_admins() or localStatus == "vip":
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                # Добавляем кнопки для каждого мануала
                for idx, manual in enumerate(get_manuals()):
                    button_text = f"{idx + 1}. {manual['name']}"
                    callback_data = f"manual_{idx}"
                    keyboard.add(types.InlineKeyboardButton(
                        text=button_text,
                        callback_data=callback_data
                    ))
                bot.send_message(
                    id,
                    "Выберите интересующий вас совет:",
                    reply_markup=keyboard
                )
            else:
                bot.reply_to(message, f"Недостаточно прав, ваш статус: {localStatus}")
        elif message.text == "Нейросеть 🤖":
            listOfAi = ""
            for i in get_ai_list():
                listOfAi = listOfAi+f"\n{i}"
            bot.reply_to(message, f"AI:\n{listOfAi}")
        #  🔐 Генерация пароля, 💻 GET-Запрос, 💰 Курс валют, 🔑 Фейк-Личность, 🤖 Создать Бота, Купить VIP 📥
        elif message.text == "🔑 Генерация пароля":
            localUserStatus = usersDB.getStatus(id)
            if id in get_admins() or localUserStatus == "vip":
                symbol_list = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890$&?!~'
                password = ""
                for i in range(4):
                    for k in range(4):
                        password += random.choice(symbol_list)
                    if i != 3: password += "-"
                bot.reply_to(message, password+'')
            else:
                bot.reply_to(message, "Недостаточно прав.")
        elif message.text == "💻 GET-Запрос":
            localUserStatus = usersDB.getStatus(message.from_user.id)
            if localUserStatus == "vip" or id in get_admins():
                bot.send_message(id, "Введите ссылку запроса:")
                bot.register_next_step_handler(message, get_request)
            else:
                bot.reply_to(message, "Недостаточно прав.")
        elif message.text == "💰 Курс валют":
            response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
            data = response.json()

            # Безопасное получение данных
            rates = data.get('rates', {})
            base = data.get('base', 'USD')
            date = data.get('date', 'Неизвестно')

            # Формируем ответ
            response_text = (
                f"💹 Курсы валют на {date}\n\n"
                f"Базовая валюта: {base}\n\n"
                f"EUR: {rates.get('EUR', 'Нет данных')}\n"
                f"RUB: {rates.get('RUB', 'Нет данных')}\n"
                f"GBP: {rates.get('GBP', 'Нет данных')}\n"
                f"JPY: {rates.get('JPY', 'Нет данных')}\n"
                f"CNY: {rates.get('CNY', 'Нет данных')}"
            )

            bot.reply_to(message, response_text)
        elif message.text == "👨 Фейк-Личность":
            localStatus = usersDB.getStatus(id)
            if id in get_admins() or localStatus == "vip":
                profile = fake.profile()

                # Получаем все данные с проверкой наличия ключей
                name = profile.get('name', 'Неизвестно')
                address = profile.get('address', 'Неизвестно')
                email = profile.get('mail', 'Неизвестно')
                phone = profile.get('phone_number', fake.phone_number())  # Если ключа нет - генерируем телефон
                birthdate = profile.get('birthdate', 'Неизвестно')
                user_id = profile.get('id', 'Неизвестно')
                company = profile.get('company', 'Неизвестно')
                job = profile.get('job', 'Неизвестно')

                # Генерация российских документов
                passport = f"{random.randint(100000, 999999)} {random.randint(100000, 999999)}"  # Серия и номер паспорта
                inn = ''.join([str(random.randint(0, 9)) for _ in range(12)])  # ИНН
                snils = f"{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(100, 999)} {random.randint(0, 99)}"  # СНИЛС

                response = (
                    "🔑 Сгенерированная личность:\n\n"
                    f"Имя: {name}\n"
                    f"Адрес: {address}\n"
                    f"Email: {email}\n"
                    f"Телефон: {phone}\n"
                    f"Дата рождения: {birthdate}\n"
                    f"ID: {user_id}\n"
                    f"Компания: {company}\n"
                    f"Должность: {job}\n"
                    f"Паспорт: {passport}\n"
                    f"ИНН: {inn}\n"
                    f"СНИЛС: {snils}"
                )
                bot.reply_to(message, response)
            else:
                bot.reply_to(message, "Недостаточно прав.")
        elif message.text == "🤖 Создать Бота":
            bot.reply_to(message, "Введите описание бота сообщением:")
            bot.register_next_step_handler(message, create_bot)
        elif message.text == "Купить VIP 📥":
            localStatus = usersDB.getStatus(id)
            if localStatus != "vip":
                cost = 0.35
                bot.reply_to(message, "Купить вип можно у владельца @kotuk0iq\nДоступные способы оплаты:\n * CryptoBot\n * Tonkeeper\n * Перевод на Т2")
            else:
                bot.reply_to(message, f"У вас уже статус {localStatus}! Вы не можете купить VIP!")
        elif message.text == "🔗 Реферальная система":
            referred_by = usersDB.get_reffered_by(id)
            referral_count = usersDB.get_referral_count(id)

            # Получаем статус VIP
            vip_status = usersDB.check_vip_status(id)
            vip_end_date = vip_status[1] if vip_status and len(vip_status) > 1 else "Не активен"

            msg = (
                f"[{id}] {username}\n"
                f"{get_date()}\n\n"
                f"Вас пригласил: {referred_by}\n"
                f"Вы пригласили - {referral_count} людей\n"
                f"Ваша ссылка: https://t.me/official_toolbot?start={id}\n"
                f"Вип действует до: {vip_end_date}\n"
                "За каждые 3 человека - +2 дня випа"
            )

            bot.send_message(id, msg)
        elif message.text == "🔐 PROXY":
            keyboard = types.InlineKeyboardMarkup(row_width=2)

            # Создаем кнопки
            for proxy_name, proxy_info in get_all_proxy().items():
                # Берем только первое слово для названия кнопки
                button_text = proxy_name.split('.')[0]
                callback_data = f"proxy_{proxy_name}"

                keyboard.add(
                    types.InlineKeyboardButton(
                        text=button_text,
                        callback_data=callback_data
                    )
                )

            bot.send_message(
                message.chat.id,
                "Выберите прокси:",
                reply_markup=keyboard
            )
        else:
            bot.reply_to(message, "Неизвестная команда")

    except Exception as e:
        print(f"{get_time()} | Ошибка в commands: \"{e}\"")


@bot.callback_query_handler(func=lambda call: call.data.startswith('proxy_'))
def proxy_callback(call):
    try:
        # Получаем название прокси из callback_data
        proxy_name = call.data.replace('proxy_', '')

        # Получаем информацию о прокси
        proxy_info = get_all_proxy().get(proxy_name, "Информация не найдена")

        # Отправляем подробную информацию
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=f"Информация о прокси:\n\n{proxy_name}\n\n{proxy_info}"
        )

    except Exception as e:
        bot.answer_callback_query(call.id, "Произошла ошибка")
        print(f"{get_time()} | Ошибка в proxy_callback: {e}")

def get_request(message):
    try:
        args = message.text.split()

        url = args[0]

        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                response_text = response.text[:2000]  # Берем первые 2000 символов
                bot.reply_to(message, f"Статус: {response.status_code}\n\nОтвет:\n{response_text}")
            else:
                bot.reply_to(message, f"Ошибка запроса. Статус: {response.status_code}")

        except RequestException as e:
            bot.reply_to(message, f"Ошибка при выполнении запроса: {str(e)}")

    except Exception as e:
        bot.reply_to(message, "Произошла ошибка")
        print(f"{get_time()} | Ошибка в GET-запросе: {e}")

def create_bot(message):
    try:
        user_text = message.text

        # Проверяем длину сообщения
        if len(user_text) < 10:
            bot.reply_to(message, "Описание слишком короткое. Напишите подробнее.")
            return

        if len(user_text) > 4096:
            bot.reply_to(message, "Описание слишком длинное. Сократите текст.")
            return

        # Собираем информацию о пользователе
        user_id = message.from_user.id
        username = message.from_user.username
        full_name = message.from_user.first_name + ' ' + message.from_user.last_name

        # Формируем текст с дополнительной информацией
        formatted_text = (
            f"ID: {user_id}\n"
            f"@{username}\n"
            f"Ссылка: https://t.me/openmessage?user_id={user_id}\n\n"  # Обратите внимание: для ссылок на пользователей используется другой формат
            f"Новое описание бота от {full_name}:\n\n{user_text}\n\n#бот"
        )

        # Отправляем сообщение
        bot.send_message(
            chat_id=get_chat_id(),
            text=formatted_text,
            parse_mode='Markdown'
        )

        bot.reply_to(message, "Описание успешно отправлено!")

    except Exception as e:
        bot.reply_to(message, "Произошла ошибка при отправке сообщения")
        print(f"{get_time()} | Ошибка при отправке сообщения: {e}")


@bot.callback_query_handler(func=lambda call: call.data.startswith('manual_'))
def manual_callback(call):
    try:
        # Получаем индекс мануала из callback_data
        idx = int(call.data.split('_')[1])

        # Получаем выбранный мануал
        manual = get_manuals()[idx]

        # Формируем сообщение
        response = (
            f"📘 {manual['name']}\n\n"
            f"Описание: {manual['description']}\n\n"
            f"Инструкция:\n{manual['content']}"
        )

        # Отправляем сообщение
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=response,
            parse_mode='Markdown'
        )

    except Exception as e:
        bot.answer_callback_query(call.id, "Произошла ошибка при загрузке совета")
        print(f"{get_time()} | Ошибка в manual_callback: {e}")

# def get_user_id_by_username(username):
#     try:
#         if username.startswith('@'):
#             username = username[1:]

#         user_info = bot.get_user_profile_photos(username)
#         return user_info.id
#
#     except Exception as e:
#         print(f"Ошибка при получении ID пользователя: {e}")
#         return None



def process_searching(message):
    user_id = message.from_user.id
    username = message.text.replace("@", "")

    try:
        # Получаем данные из базы
        mas = peoplesDB.search_by_username(username)  # Используем новый метод
        if mas != None:
            rID, rST = mas  # Распаковываем все поля
            # Определяем статус
            stic = "🟡"
            if rST == "Scammer":
                stic = "🔴"
            elif rST == "Verificated":
                stic = "🟢"

            # Формируем сообщение
            msg = (
                f"👤 ПОЛЬЗОВАТЕЛЬ @{username} НАЙДЕН!\n\n"
                f"🆔 {rID}\n\n"
                f"{stic} {rST}\n\n"
                f"by @official_ToolBot"
            )
            bot.send_message(user_id, msg)
        else:

            msgNone = (
                f"👤 ПОЛЬЗОВАТЕЛЬ @{username} НЕ НАЙДЕН!\n\n"
                f"🆔 ---------\n\n"
                f"🟡 Undefined\n\n"
                f"by @official_ToolBot"
            )
            bot.send_message(user_id, msgNone)

    except Exception as e:
        bot.send_message(user_id, "Произошла ошибка при поиске.")
        print(f"{get_time()} | Ошибка в process_searching: {e}")


bot.polling(non_stop=True, interval=1)