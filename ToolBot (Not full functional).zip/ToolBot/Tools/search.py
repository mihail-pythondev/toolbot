# end_date = datetime.now() + timedelta(days=duration_days)
# end_date_str = end_date.strftime("%Y-%m-%d %H:%M:%S")

# admin_commands = {
#     "/set_vip {id}":"Установить вип статус",
#     "/del_vip {id}":"Удалить вип статус",
#     "/add_admin {id}":"Добавить админа",
#     "/del_admin {id}":"Удалить админа",
#     "/add_channel {username}":"Добавить спонсора",
#     "/del_channel {username}":"Удалить спонсора",
#     "/add_ai {username}":"Добавить ссылку на бота с ИИ",
#     "/del_ai {username}":"Удалить ссылку на бота с ИИ",
#     "/set_chat_id {integer_id}":"Установить айди для чата с созданием ботов",
#     "/create_manual {name}":"Создать мануал",
#     "/delete_manual":"Удалить мануал",
#     "/subcribers":"Количество пользователей в боте",
#     "/set_scammer {id}":"Установить статус скамера",
#     "/set_none {id}":"Установить статус Undefined",
#     "/set_verif {id}":"Установить статус проверенного",
#     "/add_user {id} {username}":"Добавить пользователя в бд скамеров (со статусом Undefined)",
#     "/say {id} {text}":"Отправить кому-то сообщение"
# }