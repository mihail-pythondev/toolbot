import sqlite3 as sql
from datetime import datetime, timedelta


def get_date():
    date = datetime.now()
    date_str = date.strftime("%Y-%m-%d %H:%M:%S")
    return date_str


types = ["users", "peoples"]
tables = {
    "users": "(id INTEGER PRIMARY KEY, status TEXT, vip_end_date TEXT, referred_by INTEGER, referral_count INTEGER)",
    "peoples": "(id INTEGER PRIMARY KEY, username TEXT, status TEXT)"
}

VIP_DURATION = 30  # в днях


def start():
    con = sql.connect("database.db")
    cur = con.cursor()
    return con, cur


def end(con):
    con.commit()
    con.close()
    return True


class Database:
    def __init__(self, dbType):
        self.type = dbType
        if self.type in types:
            print(f"{get_date()} | объект 'Database.{self.type}' создан правильно!")
            self._create_table()
            self._check_columns()  # Проверяем структуру таблицы
        else:
            print(f"объект 'Database' имеет ошибку")

    def _create_table(self):
        try:
            con = sql.connect("database.db")
            cur = con.cursor()
            cur.execute(f"CREATE TABLE IF NOT EXISTS {self.type} {tables[self.type]}")
            con.commit()
            con.close()
        except Exception as e:
            print(f"{get_date()} | Ошибка при создании таблицы: {e}")

    def _check_columns(self):
        try:
            con = sql.connect("database.db")
            cur = con.cursor()

            # Проверяем наличие всех необходимых столбцов
            if self.type == "users":
                cur.execute("PRAGMA table_info(users)")
                columns = cur.fetchall()
                column_names = [column[1] for column in columns]

                # Добавляем отсутствующие столбцы
                if "vip_end_date" not in column_names:
                    print(f"{get_date()} | Добавление столбца vip_end_date...")
                    cur.execute("ALTER TABLE users ADD COLUMN vip_end_date TEXT")
                    con.commit()
                if "referred_by" not in column_names:
                    print(f"{get_date()} | Добавление столбца referred_by...")
                    cur.execute("ALTER TABLE users ADD COLUMN referred_by INTEGER")
                    con.commit()
                if "referral_count" not in column_names:
                    print(f"{get_date()} | Добавление столбца referral_count...")
                    cur.execute("ALTER TABLE users ADD COLUMN referral_count INTEGER")
                    con.commit()

            con.close()
        except Exception as e:
            print(f"{get_date()} | Ошибка при проверке структуры таблицы: {e}")

    def addUser(self, id, username=None, status="Undefined"):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("INSERT INTO users(id, status, vip_end_date) VALUES(?, ?, ?)",
                            (id, status, None))  # Используем None для даты
                end(con)
            elif self.type == "peoples":
                con, cur = start()
                cur.execute("INSERT INTO peoples(id, username, status) VALUES(?, ?, ?)",
                            (id, username, status))
                end(con)
        except Exception as e:
            print(f"{get_date()} | Ошибка в addUser: \"{e}\"")

    def setDate(self, id, date):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("UPDATE users SET vip_end_date = ? WHERE id = ?", (date, id))
                end(con)
            else:
                print(f"{self.type} != users")
        except Exception as e:
            print(f"{get_date()} | Ошибка в setDate: \"{e}\"")

    def getData(self, id=None, username=None):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT status, vip_end_date FROM users WHERE id = ?", [id])
                result = cur.fetchone()
                end(con)
                return result
        except Exception as e:
            print(f"{get_date()} | Ошибка в getData: \"{e}\"")

    def user_exists_in_peoples(self, id):
        con, cur = start()
        cur.execute("SELECT 1 FROM peoples WHERE id = ?", (id,))
        result = cur.fetchone()
        end(con)
        return result is not None

    def delete_user_from_peoples(self, user_id):
        try:
            # Проверяем существование пользователя перед удалением
            if not self.user_exists_in_peoples(user_id):
                print(f"{get_date()} | Пользователь {user_id} не найден в базе данных")
                return False

            con, cur = start()
            cur.execute("""
            DELETE FROM peoples 
            WHERE id = ?
            """, (user_id,))
            end(con)

            print(f"{get_date()} | Пользователь {user_id} успешно удален из таблицы peoples")
            return True

        except Exception as e:
            print(f"{get_date()} | Ошибка при удалении пользователя {user_id}: {e}")
            return False

    def setData(self, id, status="user", username=None, vip_end_date=None):
        try:
            if self.type == "users":
                if status in ["user", "vip"]:
                    # Проверяем существование пользователя
                    if not self.check_user_exists(id):
                        pass
                    else:
                        # Если есть - обновляем статус
                        con, cur = start()
                        cur.execute("UPDATE users SET status = ?, vip_end_date = ? WHERE id = ?",
                                    (status, vip_end_date, id))
                        end(con)

            elif self.type == "peoples":
                # Проверяем существование пользователя
                if not self.user_exists_in_peoples(id):
                    pass
                else:
                    # Если есть - обновляем данные
                    con, cur = start()
                    cur.execute("UPDATE peoples SET username = ?, status = ? WHERE id = ?",
                                (username, status, id))
                    end(con)

        except Exception as e:
            print(f"{get_date()} | Ошибка в setData: \"{e}\"")

    def getStatus(self, id):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT status FROM users WHERE id = ?", [int(id)])
                result = cur.fetchone()
                end(con)
                return result[0] if result else None
        except Exception as e:
            print(f"{get_date()} | Ошибка в getStatus: \"{e}\"")
            return None

    def getStatus_people(self, username):
        try:
            if self.type == "peoples":
                con, cur = start()
                cur.execute("SELECT status FROM peoples WHERE username = ?", [username])
                result = cur.fetchone()
                end(con)
                return result[0] if result else None
        except Exception as e:
            print(f"{get_date()} | Ошибка в getStatus_people: \"{e}\"")
            return None

    def getId_people(self, username):
        try:
            if self.type == "peoples":
                con, cur = start()
                cur.execute("SELECT id FROM peoples WHERE username = ?", [username])
                result = cur.fetchone()
                end(con)
                return result[0] if result else None
        except Exception as e:
            print(f"{get_date()} | Ошибка в getId_people: \"{e}\"")
            return None

    def debug_users_table(self):
        try:
            con = sql.connect("database.db")
            cur = con.cursor()
            cur.execute("SELECT * FROM users")
            all_users = cur.fetchall()
            print("DEBUG: Все пользователи в базе:")
            for user in all_users:
                print(user)
            con.close()
            return all_users
        except Exception as e:
            print(f"Ошибка при получении пользователей: {e}")
            return []

    def get_user_count(self):
        try:
            con = sql.connect("database.db")
            cur = con.cursor()
            cur.execute("SELECT COUNT(*) FROM users")
            result = cur.fetchone()
            con.close()
            return result[0] if result else 0
        except Exception as e:
            print(f"{get_date()} | Ошибка в get_user_count: \"{e}\"")
            return 0

    def check_vip_status(self, user_id):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT vip_end_date FROM users WHERE id = ?", [user_id])
                vip_end_date = cur.fetchone()
                end(con)

                if vip_end_date and vip_end_date[0]:
                    vip_end_date = datetime.strptime(vip_end_date[0], "%Y-%m-%d %H:%M:%S")
                    if datetime.now() > vip_end_date:
                        self.setData(user_id, status="user", vip_end_date=None)
                        return False
                    return True, vip_end_date
                return False
        except Exception as e:
            print(f"{get_date()} | Ошибка в check_vip_status: \"{e}\"")
            return False

    def grant_vip(self, user_id, duration_days=VIP_DURATION):
        try:
            if self.type == "users":
                end_date = datetime.now() + timedelta(days=duration_days)
                end_date_str = end_date.strftime("%Y-%m-%d %H:%M:%S")
                con, cur = start()
                cur.execute("UPDATE users SET status = 'vip', vip_end_date = ? WHERE id = ?",
                            (end_date_str, user_id))
                end(con)
                return True
        except Exception as e:
            print(f"{get_date()} | Ошибка в grant_vip: \"{e}\"")
            return False

    def broadcast_message(self, bot, message_text):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT id FROM users")  # Получаем все ID пользователей
                users = cur.fetchall()
                end(con)

                sent_count = 0
                failed_count = 0

                for user in users:
                    user_id = user[0]
                    try:
                        bot.send_message(user_id, message_text)
                        sent_count += 1
                    except Exception as e:
                        print(f"{get_date()} | Ошибка при отправке сообщения пользователю {user_id}: {str(e)}")
                        failed_count += 1

                return sent_count, failed_count

        except Exception as e:
            print(f"{get_date()} | Ошибка в broadcast_message: \"{e}\"")
            return 0, 0

    def search_by_username(self, username):
        try:
            if self.type != "peoples":
                raise ValueError(f"{get_date()} | Метод доступен только для таблицы peoples")

            if not username:
                raise ValueError(f"{get_date()} | Username не может быть пустым")

            con, cur = start()
            cur.execute("""
                SELECT id, status 
                FROM peoples 
                WHERE username = ?
            """, (username,))

            result = cur.fetchone()
            end(con)
            return result

        except Exception as e:
            print(f"{get_date()} | Ошибка в search_by_username: \"{e}\"")
            return None

    def delete_user(self, user_id):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
                end(con)
                return True
            elif self.type == "peoples":
                con, cur = start()
                cur.execute("DELETE FROM peoples WHERE id = ?", (user_id,))
                end(con)
                return True
        except Exception as e:
            print(f"{get_date()} | Ошибка при удалении пользователя: \"{e}\"")
            return False

    def get_all_users(self):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT * FROM users")
                users = cur.fetchall()
                end(con)
                return users
            elif self.type == "peoples":
                con, cur = start()
                cur.execute("SELECT * FROM peoples")
                users = cur.fetchall()
                end(con)
                return users
        except Exception as e:
            print(f"{get_date()} | Ошибка при получении всех пользователей: \"{e}\"")
            return []

    def get_vip_users(self):
        try:
            if self.type == "users":
                con, cur = start()
                cur.execute("SELECT * FROM users WHERE status = 'vip' AND vip_end_date > ?",
                            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
                vip_users = cur.fetchall()
                end(con)
                return vip_users
        except Exception as e:
            print(f"{get_date()} | Ошибка при получении VIP пользователей: \"{e}\"")
            return []

    def add_user_with_referral(self, user_id, referred_by=0, bot=None):
        try:
            # Проверяем, существует ли уже пользователь в базе
            if self.check_user_exists(user_id):
                print(f"{get_date()} | Пользователь {user_id} уже зарегистрирован")
                return False

            if referred_by:
                # Проверяем, существует ли реферирующий пользователь
                if not self.check_user_exists(referred_by):
                    referred_by = None
                # Обновляем счетчик рефералов у пригласившего
                self.update_referral_count(referred_by)
                bot.send_message(referred_by, f"Вы пригласили пользователя {user_id}")

            con, cur = start()
            cur.execute("""
            INSERT INTO users (id, status, vip_end_date, referred_by, referral_count) 
            VALUES (?, ?, ?, ?, ?)
            """, (user_id, "user", None, referred_by, 0))
            end(con)
            return True
        except Exception as e:
            print(f"{get_date()} | Ошибка при добавлении пользователя с рефералом: {e}")
            return False

    def check_user_exists(self, user_id):
        try:
            con, cur = start()
            cur.execute("SELECT 1 FROM users WHERE id = ?", (user_id,))
            exists = cur.fetchone() is not None
            end(con)
            return exists
        except Exception as e:
            print(f"{get_date()} | Ошибка при проверке существования пользователя: {e}")
            return False

    def update_referral_count(self, user_id):
        try:
            # Получаем текущий счетчик рефералов
            current_count = self.get_referral_count(user_id)

            # Проверяем, что current_count не None
            if current_count is None:
                current_count = 0

            # Увеличиваем счетчик
            new_count = current_count + 1

            # Обновляем в базе данных
            con, cur = start()
            cur.execute("UPDATE users SET referral_count = ? WHERE id = ?",
                        (new_count, user_id))
            end(con)

            # Проверяем условия для VIP
            if new_count % 3 == 0:
                self.extend_vip(user_id, 2)  # Добавляем 2 дня VIP

            return new_count

        except Exception as e:
            print(f"{get_date()} | Ошибка при обновлении счетчика рефералов: {e}")
            return None

    def extend_vip(self, user_id, days):
        try:
            con, cur = start()
            cur.execute("SELECT vip_end_date FROM users WHERE id = ?", (user_id,))
            current_date = cur.fetchone()[0]

            if current_date:
                vip_end_date = datetime.strptime(current_date, "%Y-%m-%d %H:%M:%S")
            else:
                vip_end_date = datetime.now()

            new_end_date = vip_end_date + timedelta(days=days)
            cur.execute("UPDATE users SET vip_end_date = ?, status = 'vip' WHERE id = ?",
                        (new_end_date.strftime("%Y-%m-%d %H:%M:%S"), user_id))
            end(con)
        except Exception as e:
            print(f"{get_date()} | Ошибка при продлении VIP: {e}")

    def get_referral_count(self, user_id):
        try:
            con, cur = start()
            cur.execute("SELECT referral_count FROM users WHERE id = ?", (user_id,))
            result = cur.fetchone()
            if result == None: result = 0
            end(con)
            return result[0] if result else 0
        except Exception as e:
            print(f"{get_date()} | Ошибка при получении количества рефералов: {e}")
            return 0

    def get_reffered_by(self, user_id):
        try:
            con, cur = start()
            cur.execute("SELECT referred_by FROM users WHERE id = ?", (user_id))
            result = cur.fetchone()
            end(con)
            return result[0] if result else 0
        except Exception as e:
            print(f"{get_date()} | Ошибка при получении reffered_by: {e}")



    def __del__(self):
        print(f"{get_date()} | Объект 'Database.{self.type}' уничтожен")